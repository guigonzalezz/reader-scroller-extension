# reader-scroller-extension
Extension for scrolling down a page using for reading or seeing a tab on browser 
